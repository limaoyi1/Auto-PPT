"""
rectangle
"""

# Expected units are those of md2pptx
class Rectangle:
    def __init__(self, top, left, height, width):
        self.top = top
        self.left = left
        self.height = height
        self.width = width

