pageTitleSize: 30
sectionTitleSize: 48
sectionSubtitleSize: 32
numbers: no
abstractTitle: Abstract


# Even More Fun With DDF
Martin Packer 🦕 , IBM

### Abstract


|![](Battery W2M.png)||
|![](Battery W2M.png)|![](Battery W3M.png)|

