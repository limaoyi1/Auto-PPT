pageTitleSize: 30
sectionTitleSize: 48
sectionSubtitleSize: 32
numbers: no
abstractTitle: Abstract
template: Martin Template.pptx


# Even More Fun With DDF
Martin Packer 🦕 , IBM

### SVG Test

![](EnclaveCadence.svg)

### Web SVG Sample

![](https://cdn.shopify.com/s/files/1/0496/1029/files/Freesample.svg?5153)

### Web PNG Example

![](https://ichef.bbci.co.uk/live-experience/cps/624/cpsprodpb/vivo/live/images/2021/1/31/4405412f-3c56-486a-9fda-77b1633e2dbe.jpg)


### PNG file

![](Battery W3M.png)

